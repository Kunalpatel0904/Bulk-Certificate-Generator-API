# Bulk Certificate Generator

A backend API that accepts a list of recipients in **one request**, generates a PDF
certificate for each valid recipient from a single predefined template, tracks progress per
job, and lets the client download the results individually or as a ZIP.

**Stack:** Python 3.10+, FastAPI, SQLAlchemy 2 (SQLite by default, any SQL database via
`DATABASE_URL`), ReportLab (PDF), pytest.

A sample output is in [`examples/sample_certificate.pdf`](examples/sample_certificate.pdf).

---

## Setup

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt  # use requirements.txt for runtime only
```

## Run the application

```bash
uvicorn app.main:create_app --factory --reload
```

* API: http://127.0.0.1:8000  ·  Interactive docs (Swagger): http://127.0.0.1:8000/docs
* Tables are created automatically on startup. Data goes to `./data/` (SQLite file + PDFs).

| Environment variable     | Default                          | Meaning                                  |
|--------------------------|----------------------------------|------------------------------------------|
| `DATABASE_URL`           | `sqlite:///./data/certgen.db`    | Any SQLAlchemy URL (e.g. PostgreSQL)     |
| `STORAGE_DIR`            | `./data/certificates`            | Where generated PDFs are stored          |
| `MAX_RECIPIENTS_PER_JOB` | `1000`                           | Max recipients accepted per request      |

## Run the tests

```bash
pytest
```

40 tests; each uses its own temporary database and storage directory.

---

## API usage

### 1. Submit a generation request

```bash
curl -s -X POST http://127.0.0.1:8000/api/v1/jobs \
  -H "Content-Type: application/json" \
  -d @examples/sample_request.json
```

Response `202 Accepted` (also sets a `Location` header):

```json
{
  "job_id": "5c1e0f3e-....",
  "status": "queued",
  "counts": {"total": 6, "pending": 3, "succeeded": 0, "failed": 3,
             "failed_validation": 3, "failed_generation": 0},
  "progress_percent": 50.0,
  "links": {"self": "/api/v1/jobs/5c1e...", "certificates": "...", "download_all": "...", "retry": "..."}
}
```

Request fields: `event_name` (required), `issuer` (optional), `issued_on` (optional, `YYYY-MM-DD`,
defaults to today), `recipients[]` with `name` and `email` (required) and `achievement` (optional).

### 2. Check progress / result

```bash
curl -s http://127.0.0.1:8000/api/v1/jobs/<job_id>
```

`status` is one of `queued`, `processing`, `completed` (all succeeded),
`completed_with_errors`, `failed` (none succeeded). `counts` and `progress_percent` update
while the job runs.

Per-recipient results (paginated, filterable):

```bash
curl -s "http://127.0.0.1:8000/api/v1/jobs/<job_id>/certificates?status=failed&limit=100&offset=0"
```

Each item has `position` (0-based index in the list you sent), `status`
(`pending|success|failed`), `failure_stage` (`validation|generation`) and a human-readable `error`.

### 3. Retrieve certificates

```bash
# one certificate (use download_url from the listing)
curl -OJ http://127.0.0.1:8000/api/v1/jobs/<job_id>/certificates/<certificate_id>/file

# everything that succeeded, as a ZIP (available once the job has finished)
curl -OJ http://127.0.0.1:8000/api/v1/jobs/<job_id>/download
```

### 4. Retry generation failures (optional)

```bash
curl -X POST http://127.0.0.1:8000/api/v1/jobs/<job_id>/retry
```

### Endpoint summary

| Method | Path                                              | Purpose                         |
|--------|---------------------------------------------------|---------------------------------|
| POST   | `/api/v1/jobs`                                    | Create a bulk job (202)         |
| GET    | `/api/v1/jobs/{id}`                               | Status, counts, progress        |
| GET    | `/api/v1/jobs/{id}/certificates`                  | Per-recipient results           |
| GET    | `/api/v1/jobs/{id}/certificates/{cid}`            | One certificate's record        |
| GET    | `/api/v1/jobs/{id}/certificates/{cid}/file`       | Download one PDF                |
| GET    | `/api/v1/jobs/{id}/download`                      | Download all as ZIP             |
| POST   | `/api/v1/jobs/{id}/retry`                         | Re-run generation failures      |
| GET    | `/health`                                         | Liveness                        |

---

## Design decisions

**Asynchronous processing with FastAPI `BackgroundTasks`.** `POST /jobs` validates and
persists the job, then returns `202` immediately; certificates are generated in the
background and the client polls. Generating thousands of PDFs inside the request would hit
client/proxy timeouts, so synchronous processing doesn't scale to "bulk". I chose
`BackgroundTasks` over Celery/RQ because it needs no broker or extra process, and the work
is small (about 1,000 certificates in ~3 s locally). The job state lives in the database,
so moving to a real queue later only changes how `process_job(job_id)` is invoked.

**Per-recipient validation, not all-or-nothing.** Only structural problems (missing
`event_name`, empty list, too many recipients, unrenderable event/issuer text) reject the
request (`422`/`413`). Each recipient is validated separately: invalid ones are stored as
`failed` with `failure_stage=validation` and a reason, while valid ones proceed. Checks:
non-empty name (max 80 chars), valid email, no duplicate emails in a job (case-insensitive),
and text the PDF font can draw.

**Failure isolation.** Every certificate is generated inside its own `try/except` and its
result is committed immediately. One failure is recorded (`failure_stage=generation`, with
the error) and the loop continues. Per-certificate commits also make progress visible live.
PDFs are written to a temp file and renamed, so a crash never leaves a half-written file.

**Data model.** `jobs` (1) → `certificates` (N). Counts and progress are computed from
certificate rows with one `GROUP BY` query, so there are no counters to drift out of sync.
Statuses are plain strings (portable across databases, no enum types).

**Safe concurrency.** A job is claimed with an atomic
`UPDATE ... WHERE status='queued'`, so it can never be processed by two workers at once.
Only `pending` rows are processed, so re-running a job resumes rather than redoes work.
SQLite runs in WAL mode so status requests can read while the worker writes.

**Crash recovery.** On startup, jobs stuck in `processing` are re-queued and resumed.

**Template.** One landscape A4 template drawn with ReportLab and PDF built-in fonts (no
font files to ship). Long names shrink to fit; long event names wrap. Files are named from
the generated certificate number, never from user input, so there is no path-traversal risk.

**Testability.** `create_app(settings, generator)` takes injectable settings and a
certificate generator. Tests use a temp database per test, and inject a failing generator to
test per-certificate failures. Starlette's `TestClient` runs background tasks before
returning, so tests are deterministic.

## Limitations / what I'd do next

* **Fonts:** built-in fonts cover English and accented Latin letters. Names in other scripts
  (e.g. Devanagari) are rejected at validation with a clear message. Supporting them needs a
  bundled Unicode font (and text shaping for Indic scripts).
* **Single process:** `BackgroundTasks` runs inside the API process and startup recovery
  assumes one instance. For multiple workers or horizontal scale, switch to a durable queue
  (Celery/RQ/Arq) with the same `process_job` function.
* **No auth or rate limiting;** download URLs rely on unguessable UUIDs only.
* **Local file storage;** use S3/GCS and signed URLs in production.
* **No migrations;** tables come from `create_all`. Use Alembic for schema evolution.
* **Idempotency keys** on `POST /jobs` would protect against duplicate submits on client retries.

## Project layout

```
app/
  main.py              app factory, startup recovery
  config.py            env-based settings
  database.py          engine, UTC datetime type
  models.py            Job, Certificate
  schemas.py           request/response models
  routers/jobs.py      HTTP endpoints
  services/
    validation.py      per-recipient validation
    certificate.py     PDF template + generator
    processor.py       background job processing, recovery
    jobs.py            counts / progress view
tests/                 40 tests (create, validation, generation, status, failures, retrieval, recovery)
examples/              sample request + sample certificate PDF
```
