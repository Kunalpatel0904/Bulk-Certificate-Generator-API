from datetime import date

from app.models import Certificate, Job, JobStatus
from app.services.certificate import generate_certificate_pdf
from app.services.jobs import job_counts
from tests.conftest import recipients


def test_status_lifecycle_completed(client, submit):
    job = client.get(submit().json()["links"]["self"]).json()
    assert job["status"] == "completed"
    assert job["started_at"] and job["finished_at"]
    assert job["counts"] == {
        "total": 3, "pending": 0, "succeeded": 3,
        "failed": 0, "failed_validation": 0, "failed_generation": 0,
    }


def test_progress_is_visible_while_job_is_running(make_app):
    """The generator inspects the DB mid-run: counts must already reflect progress."""
    from fastapi.testclient import TestClient

    holder, snapshots = {}, []

    def spying_generator(data, path):
        with holder["app"].state.ctx.session_factory() as db:
            job = db.query(Job).one()
            snapshots.append((job.status, job_counts(db, job.id).succeeded))
        generate_certificate_pdf(data, path)

    holder["app"] = make_app(spying_generator)
    r = TestClient(holder["app"]).post(
        "/api/v1/jobs", json={"event_name": "E", "issuer": "I", "recipients": recipients(3)}
    )
    assert r.status_code == 202
    assert snapshots == [("processing", 0), ("processing", 1), ("processing", 2)]


def test_status_completed_with_errors_and_failed(make_app):
    from fastapi.testclient import TestClient

    def fail_named_bad(data, path):
        if data.name.startswith("Bad"):
            raise RuntimeError("render error")
        generate_certificate_pdf(data, path)

    c = TestClient(make_app(fail_named_bad))
    mixed = c.post("/api/v1/jobs", json={"event_name": "E", "recipients": [
        {"name": "Good", "email": "g@example.com"}, {"name": "Bad", "email": "b@example.com"}]})
    assert c.get(mixed.json()["links"]["self"]).json()["status"] == "completed_with_errors"

    all_bad = c.post("/api/v1/jobs", json={"event_name": "E", "recipients": [
        {"name": "Bad 1", "email": "b1@example.com"}, {"name": "Bad 2", "email": "b2@example.com"}]})
    body = c.get(all_bad.json()["links"]["self"]).json()
    assert body["status"] == "failed"
    assert body["counts"]["failed_generation"] == 2


def test_in_flight_job_reports_partial_progress(client, app):
    with app.state.ctx.session_factory() as db:
        job = Job(event_name="E", issuer="I", issued_on=date.today(),
                  status=JobStatus.PROCESSING.value, total=4)
        db.add(job); db.flush()
        for i, st in enumerate(["success", "success", "pending", "pending"]):
            db.add(Certificate(job_id=job.id, position=i, name=f"N{i}", email=f"n{i}@example.com",
                               status=st, certificate_number=f"C{i}"))
        db.commit()
        job_id = job.id
    body = client.get(f"/api/v1/jobs/{job_id}").json()
    assert body["status"] == "processing"
    assert body["progress_percent"] == 50.0
    assert body["counts"]["pending"] == 2
