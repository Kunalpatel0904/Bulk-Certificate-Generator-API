import io
import zipfile
from datetime import date

from fastapi.testclient import TestClient
from pypdf import PdfReader

from app.models import Certificate, Job, JobStatus
from app.services.certificate import generate_certificate_pdf
from tests.conftest import recipients


def _items(client, job, **params):
    return client.get(job["links"]["certificates"], params=params).json()


def test_list_certificates_with_pagination_and_status_filter(client, submit):
    r = submit(recipients(5) + [{"name": "", "email": "bad"}])
    links = r.json()["links"]

    page = _items(client, {"links": links}, limit=2, offset=0)
    assert page["total"] == 6 and [i["position"] for i in page["items"]] == [0, 1]
    assert [i["position"] for i in _items(client, {"links": links}, limit=2, offset=4)["items"]] == [4, 5]

    ok = _items(client, {"links": links}, status="success")
    assert ok["total"] == 5 and all(i["download_url"] for i in ok["items"])
    assert _items(client, {"links": links}, status="failed")["total"] == 1


def test_download_single_certificate_pdf(client, submit):
    r = submit()
    item = _items(client, r.json())["items"][1]
    resp = client.get(item["download_url"])
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "application/pdf"
    assert item["certificate_number"] in resp.headers["content-disposition"]
    assert resp.content.startswith(b"%PDF")
    assert "Person 1" in PdfReader(io.BytesIO(resp.content)).pages[0].extract_text()


def test_get_single_certificate_record(client, submit):
    r = submit()
    item = _items(client, r.json())["items"][0]
    rec = client.get(f"{r.json()['links']['certificates']}/{item['certificate_id']}").json()
    assert rec["name"] == "Person 0" and rec["status"] == "success"


def test_failed_certificate_cannot_be_downloaded(client, submit):
    r = submit([{"name": "ok", "email": "ok@example.com"}, {"name": "", "email": "bad"}])
    failed = _items(client, r.json(), status="failed")["items"][0]
    url = f"{r.json()['links']['certificates']}/{failed['certificate_id']}/file"
    assert client.get(url).status_code == 409


def test_unknown_or_foreign_certificate_is_404(client, submit):
    a, b = submit(), submit(recipients(1, "other"))
    cert_of_b = _items(client, b.json())["items"][0]["certificate_id"]
    base = a.json()["links"]["certificates"]
    assert client.get(f"{base}/{cert_of_b}/file").status_code == 404  # wrong job
    assert client.get(f"{base}/missing/file").status_code == 404
    assert client.get("/api/v1/jobs/nope/certificates").status_code == 404


def test_download_all_zip_contains_only_successful_certificates(make_app):
    def gen(data, path):
        if data.name == "Person 1":
            raise RuntimeError("nope")
        generate_certificate_pdf(data, path)

    c = TestClient(make_app(gen))
    r = c.post("/api/v1/jobs", json={"event_name": "E", "recipients": recipients(3)})
    resp = c.get(r.json()["links"]["download_all"])
    assert resp.status_code == 200
    assert resp.headers["content-type"] == "application/zip"

    zf = zipfile.ZipFile(io.BytesIO(resp.content))
    assert zf.namelist() == ["00001_Person_0.pdf", "00003_Person_2.pdf"]
    assert all(zf.read(n).startswith(b"%PDF") for n in zf.namelist())


def test_download_all_while_job_is_still_running_is_409(client, app):
    with app.state.ctx.session_factory() as db:
        job = Job(event_name="E", issuer="I", issued_on=date.today(),
                  status=JobStatus.PROCESSING.value, total=1)
        db.add(job)
        db.commit()
        job_id = job.id
    assert client.get(f"/api/v1/jobs/{job_id}/download").status_code == 409


def test_download_all_when_nothing_succeeded_is_409(client, submit):
    r = submit([{"name": "", "email": "bad"}])
    assert client.get(r.json()["links"]["download_all"]).status_code == 409


def test_file_deleted_from_disk_returns_410(client, submit, settings):
    r = submit()
    item = _items(client, r.json())["items"][0]
    next((settings.storage_dir / r.json()["job_id"]).glob("*00001.pdf")).unlink()
    assert client.get(item["download_url"]).status_code == 410
