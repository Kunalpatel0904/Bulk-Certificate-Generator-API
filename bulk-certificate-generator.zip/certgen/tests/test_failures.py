from fastapi.testclient import TestClient

from app.services.certificate import generate_certificate_pdf


def _flaky_generator(state):
    def gen(data, path):
        if data.name == "Broken" and state["fail"]:
            raise RuntimeError("renderer exploded")
        generate_certificate_pdf(data, path)

    return gen


RECIPIENTS = [
    {"name": "First", "email": "1@example.com"},
    {"name": "Broken", "email": "2@example.com"},
    {"name": "Third", "email": "3@example.com"},
]


def test_one_generation_failure_does_not_block_the_others(make_app, settings):
    c = TestClient(make_app(_flaky_generator({"fail": True})))
    r = c.post("/api/v1/jobs", json={"event_name": "E", "recipients": RECIPIENTS})
    job = c.get(r.json()["links"]["self"]).json()

    assert job["status"] == "completed_with_errors"
    assert job["counts"]["succeeded"] == 2
    assert job["counts"]["failed_generation"] == 1

    items = c.get(job["links"]["certificates"]).json()["items"]
    by_name = {i["name"]: i for i in items}
    assert by_name["First"]["status"] == by_name["Third"]["status"] == "success"
    broken = by_name["Broken"]
    assert broken["status"] == "failed"
    assert broken["failure_stage"] == "generation"
    assert "renderer exploded" in broken["error"]
    assert broken["download_url"] is None
    assert len(list((settings.storage_dir / job["job_id"]).glob("*.pdf"))) == 2


def test_retry_regenerates_only_failed_certificates(make_app):
    state = {"fail": True}
    calls = []

    def gen(data, path):
        calls.append(data.name)
        _flaky_generator(state)(data, path)

    c = TestClient(make_app(gen))
    r = c.post("/api/v1/jobs", json={"event_name": "E", "recipients": RECIPIENTS})
    links = r.json()["links"]
    assert calls == ["First", "Broken", "Third"]

    state["fail"] = False  # the underlying problem is fixed
    retry = c.post(links["retry"])
    assert retry.status_code == 202

    assert calls == ["First", "Broken", "Third", "Broken"]  # only the failed one re-ran
    job = c.get(links["self"]).json()
    assert job["status"] == "completed"
    assert job["counts"]["succeeded"] == 3


def test_retry_with_nothing_to_retry_is_409(client, submit):
    r = submit()
    assert client.post(r.json()["links"]["retry"]).status_code == 409


def test_validation_failures_are_not_retryable(client, submit):
    r = submit([{"name": "ok", "email": "ok@example.com"}, {"name": "", "email": "bad"}])
    assert client.post(r.json()["links"]["retry"]).status_code == 409


def test_retry_unknown_job_is_404(client):
    assert client.post("/api/v1/jobs/nope/retry").status_code == 404
