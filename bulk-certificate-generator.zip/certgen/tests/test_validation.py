import pytest

from tests.conftest import payload, recipients


@pytest.mark.parametrize(
    "body",
    [
        {},  # empty
        {"recipients": recipients(1)},  # missing event_name
        {"event_name": "X"},  # missing recipients
        {"event_name": "X", "recipients": []},  # empty list
        {"event_name": "   ", "recipients": recipients(1)},  # blank event
        {"event_name": "Ev\u0928\u094d\u0924", "recipients": recipients(1)},  # unrenderable
        {"event_name": "X", "recipients": recipients(1), "issued_on": "not-a-date"},
    ],
)
def test_invalid_request_is_rejected_with_422(client, body):
    assert client.post("/api/v1/jobs", json=body).status_code == 422


def test_too_many_recipients_is_413(client, submit):
    r = submit(recipients(51))  # limit is 50 in tests
    assert r.status_code == 413


def test_invalid_recipients_fail_individually_and_valid_ones_proceed(client, submit):
    rs = [
        {"name": "Good One", "email": "good@example.com"},
        {"name": "", "email": "x@example.com"},  # empty name
        {"name": "No Email"},  # missing email
        {"name": "Bad Email", "email": "not-an-email"},
        "just a string",  # not an object
        {"name": "Good Two", "email": "two@example.com"},
        {"name": "Dup", "email": "GOOD@example.com"},  # duplicate (case-insensitive)
        {"name": "\u0930\u093e\u0939\u0941\u0932", "email": "r@example.com"},  # Devanagari
        {"name": "A" * 81, "email": "long@example.com"},
    ]
    r = submit(rs)
    assert r.status_code == 202
    # The 202 reflects the state at acceptance: 2 queued, 7 already rejected.
    assert r.json()["counts"]["pending"] == 2
    assert r.json()["counts"]["failed_validation"] == 7

    job = client.get(r.json()["links"]["self"]).json()
    assert job["status"] == "completed_with_errors"
    assert job["counts"] == {
        "total": 9, "pending": 0, "succeeded": 2,
        "failed": 7, "failed_validation": 7, "failed_generation": 0,
    }

    items = client.get(r.json()["links"]["certificates"], params={"status": "failed"}).json()["items"]
    assert [i["position"] for i in items] == [1, 2, 3, 4, 6, 7, 8]
    assert all(i["failure_stage"] == "validation" and i["error"] for i in items)
    errors = {i["position"]: i["error"] for i in items}
    assert "name" in errors[1]
    assert "email" in errors[2]
    assert "duplicate" in errors[6]
    assert "cannot render" in errors[7]


def test_name_whitespace_is_normalised(client, submit):
    r = submit([{"name": "  Asha   Verma ", "email": "a@example.com"}])
    items = client.get(r.json()["links"]["certificates"]).json()["items"]
    assert items[0]["name"] == "Asha Verma"


def test_job_with_only_invalid_recipients_is_failed_immediately(client, submit):
    r = submit([{"name": "", "email": "bad"}])
    assert r.status_code == 202
    assert r.json()["status"] == "failed"
    assert r.json()["counts"]["succeeded"] == 0
