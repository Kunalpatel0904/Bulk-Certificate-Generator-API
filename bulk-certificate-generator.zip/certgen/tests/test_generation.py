import io
from datetime import date
from pathlib import Path

import pytest
from pypdf import PdfReader

from app.services.certificate import CertificateData, generate_certificate_pdf


def _data(**kw):
    base = dict(
        name="Asha Verma", certificate_number="CERT-TEST-00001",
        event_name="Python Bootcamp", issuer="Acme Academy", issued_on=date(2026, 10, 7),
    )
    base.update(kw)
    return CertificateData(**base)


def _text(path):
    return PdfReader(str(path)).pages[0].extract_text()


def test_pdf_contains_recipient_specific_information(tmp_path):
    out = tmp_path / "c.pdf"
    generate_certificate_pdf(_data(achievement="Top Performer"), out)
    assert out.read_bytes().startswith(b"%PDF")
    text = _text(out)
    for expected in ("Asha Verma", "Python Bootcamp", "Acme Academy", "7 October 2026",
                     "CERT-TEST-00001", "Top Performer"):
        assert expected in text


def test_very_long_name_and_event_still_render(tmp_path):
    out = tmp_path / "long.pdf"
    generate_certificate_pdf(
        _data(name="W" * 80, event_name="Advanced Systems Engineering " * 4), out
    )
    assert len(PdfReader(str(out)).pages) == 1


def test_accented_names_render(tmp_path):
    out = tmp_path / "acc.pdf"
    generate_certificate_pdf(_data(name="José Núñez-O'Brien"), out)
    assert "Jos" in _text(out)


def test_failed_render_leaves_no_partial_file(tmp_path, monkeypatch):
    from reportlab.pdfgen import canvas

    def boom(self, *a, **k):
        raise OSError("disk full")

    monkeypatch.setattr(canvas.Canvas, "save", boom)
    out = tmp_path / "x.pdf"
    with pytest.raises(OSError):
        generate_certificate_pdf(_data(), out)
    assert list(Path(tmp_path).iterdir()) == []


def test_job_generates_one_pdf_per_valid_recipient(client, submit, settings):
    r = submit()
    job_id = r.json()["job_id"]
    files = sorted((settings.storage_dir / job_id).glob("*.pdf"))
    assert len(files) == 3
    assert "Person 0" in _text(files[0])
