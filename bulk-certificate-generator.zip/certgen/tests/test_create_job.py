from tests.conftest import payload, recipients


def test_create_job_returns_202_with_job_id_and_location(client, submit):
    r = submit()
    assert r.status_code == 202
    body = r.json()
    assert body["job_id"]
    assert body["counts"]["total"] == 3
    assert r.headers["location"] == f"/api/v1/jobs/{body['job_id']}"
    assert body["links"]["certificates"].endswith("/certificates")


def test_bulk_job_is_a_single_request_and_completes(client, submit):
    r = submit(recipients(40))
    job = client.get(r.json()["links"]["self"]).json()
    assert job["status"] == "completed"
    assert job["counts"]["succeeded"] == 40
    assert job["progress_percent"] == 100.0


def test_issued_on_defaults_to_today_and_can_be_set(client, submit):
    assert submit().json()["issued_on"]
    assert submit(issued_on="2026-01-31").json()["issued_on"] == "2026-01-31"


def test_get_unknown_job_is_404(client):
    assert client.get("/api/v1/jobs/does-not-exist").status_code == 404
