from datetime import date

from app.models import Certificate, Job, JobStatus
from app.services.processor import process_job, recover_incomplete_jobs


def _seed(ctx, status, cert_states):
    with ctx.session_factory() as db:
        job = Job(event_name="E", issuer="I", issued_on=date(2026, 1, 1),
                  status=status, total=len(cert_states))
        db.add(job)
        db.flush()
        for i, st in enumerate(cert_states):
            db.add(Certificate(job_id=job.id, position=i, name=f"N{i}", email=f"n{i}@example.com",
                               status=st, certificate_number=f"CERT-{i:05d}"))
        db.commit()
        return job.id


def test_interrupted_job_is_requeued_and_resumed(app):
    ctx = app.state.ctx
    job_id = _seed(ctx, JobStatus.PROCESSING.value, ["pending", "pending"])

    assert recover_incomplete_jobs(ctx.session_factory) == [job_id]
    process_job(job_id, ctx)

    with ctx.session_factory() as db:
        assert db.get(Job, job_id).status == JobStatus.COMPLETED.value


def test_a_job_is_never_processed_twice(make_app):
    calls = []
    from app.services.certificate import generate_certificate_pdf

    def gen(data, path):
        calls.append(data.name)
        generate_certificate_pdf(data, path)

    app = make_app(gen)
    ctx = app.state.ctx
    job_id = _seed(ctx, JobStatus.QUEUED.value, ["pending", "pending"])

    process_job(job_id, ctx)
    process_job(job_id, ctx)  # second claim must be a no-op
    assert calls == ["N0", "N1"]
