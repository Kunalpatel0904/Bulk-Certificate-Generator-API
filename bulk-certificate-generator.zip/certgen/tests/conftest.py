import warnings

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

warnings.filterwarnings("ignore", message=".*httpx.*")


@pytest.fixture
def settings(tmp_path):
    return Settings(
        database_url=f"sqlite:///{tmp_path / 'test.db'}",
        storage_dir=tmp_path / "certs",
        max_recipients_per_job=50,
    )


@pytest.fixture
def make_app(settings):
    """Factory so a test can inject a custom certificate generator."""

    def _make(generator=None):
        return create_app(settings, generator=generator)

    return _make


@pytest.fixture
def app(make_app):
    return make_app()


@pytest.fixture
def client(app):
    # NB: TestClient runs FastAPI background tasks before returning the response,
    # so a job is already finished when `client.post(...)` returns.
    return TestClient(app)


def recipients(n, prefix="user"):
    return [{"name": f"Person {i}", "email": f"{prefix}{i}@example.com"} for i in range(n)]


def payload(rs=None, **overrides):
    body = {"event_name": "Python Bootcamp", "issuer": "Acme Academy", "recipients": rs or recipients(3)}
    body.update(overrides)
    return body


@pytest.fixture
def submit(client):
    def _submit(rs=None, **overrides):
        return client.post("/api/v1/jobs", json=payload(rs, **overrides))

    return _submit
