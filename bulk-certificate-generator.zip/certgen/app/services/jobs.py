"""Read-side helpers: progress counts and the JobOut view."""
from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Certificate, CertificateStatus, FailureStage, Job
from ..schemas import JobCounts, JobOut

API_PREFIX = "/api/v1"


def job_counts(db: Session, job_id: str) -> JobCounts:
    rows = db.execute(
        select(Certificate.status, Certificate.failure_stage, func.count())
        .where(Certificate.job_id == job_id)
        .group_by(Certificate.status, Certificate.failure_stage)
    ).all()

    pending = succeeded = failed_validation = failed_generation = 0
    for status, stage, n in rows:
        if status == CertificateStatus.PENDING.value:
            pending += n
        elif status == CertificateStatus.SUCCESS.value:
            succeeded += n
        elif stage == FailureStage.VALIDATION.value:
            failed_validation += n
        else:
            failed_generation += n

    failed = failed_validation + failed_generation
    return JobCounts(
        total=pending + succeeded + failed,
        pending=pending,
        succeeded=succeeded,
        failed=failed,
        failed_validation=failed_validation,
        failed_generation=failed_generation,
    )


def job_links(job_id: str) -> dict[str, str]:
    base = f"{API_PREFIX}/jobs/{job_id}"
    return {
        "self": base,
        "certificates": f"{base}/certificates",
        "download_all": f"{base}/download",
        "retry": f"{base}/retry",
    }


def build_job_out(db: Session, job: Job) -> JobOut:
    counts = job_counts(db, job.id)
    done = counts.succeeded + counts.failed
    percent = round(done / counts.total * 100, 1) if counts.total else 100.0
    return JobOut(
        job_id=job.id,
        status=job.status,
        event_name=job.event_name,
        issuer=job.issuer,
        issued_on=job.issued_on,
        created_at=job.created_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        counts=counts,
        progress_percent=percent,
        links=job_links(job.id),
    )
