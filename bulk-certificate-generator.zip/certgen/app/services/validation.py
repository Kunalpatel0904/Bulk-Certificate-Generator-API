"""Validation of the request header fields and of each recipient.

Recipients are validated *individually* (not as part of the request model) so one
bad row is recorded as a failed certificate instead of rejecting the whole job.
"""
from __future__ import annotations

import unicodedata
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, ConfigDict, EmailStr, ValidationError, field_validator

MAX_NAME_LEN = 80
MAX_ACHIEVEMENT_LEN = 100
MAX_EVENT_LEN = 120
MAX_ISSUER_LEN = 80


def clean_text(value: str, *, label: str, max_len: int) -> str:
    """Normalise whitespace and make sure the text can be drawn on the PDF.

    The template uses PDF built-in fonts (no font files to ship), which cover the
    Windows-1252 character set: English plus accented Latin letters. Anything the
    font cannot draw is rejected up front rather than failing later at render time.
    """
    value = " ".join(value.split())
    if not value:
        raise ValueError(f"{label} must not be empty")
    if len(value) > max_len:
        raise ValueError(f"{label} must be at most {max_len} characters")
    if any(unicodedata.category(ch).startswith("C") for ch in value):
        raise ValueError(f"{label} must not contain control characters")
    try:
        value.encode("cp1252")
    except UnicodeEncodeError:
        raise ValueError(
            f"{label} contains characters the certificate font cannot render "
            "(supported: English and accented Latin letters)"
        ) from None
    return value


class RecipientIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    name: str
    email: EmailStr
    achievement: str | None = None

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        return clean_text(v, label="name", max_len=MAX_NAME_LEN)

    @field_validator("achievement")
    @classmethod
    def _achievement(cls, v: str | None) -> str | None:
        if v is None or not v.strip():
            return None
        return clean_text(v, label="achievement", max_len=MAX_ACHIEVEMENT_LEN)


@dataclass
class RecipientResult:
    """Outcome of validating one submitted recipient."""

    position: int
    recipient: RecipientIn | None
    error: str | None
    raw_name: str | None = None
    raw_email: str | None = None


def format_errors(exc: ValidationError) -> str:
    parts = []
    for err in exc.errors():
        loc = ".".join(str(p) for p in err["loc"]) or "recipient"
        msg = err["msg"].removeprefix("Value error, ")
        parts.append(f"{loc}: {msg}")
    return "; ".join(parts)


def _raw(item: Any, key: str) -> str | None:
    if isinstance(item, dict) and isinstance(item.get(key), str):
        return item[key][:255]
    return None


def validate_recipients(items: list[Any]) -> list[RecipientResult]:
    results: list[RecipientResult] = []
    first_seen: dict[str, int] = {}

    for position, item in enumerate(items):
        raw_name, raw_email = _raw(item, "name"), _raw(item, "email")

        if not isinstance(item, dict):
            results.append(
                RecipientResult(
                    position, None, "recipient must be an object with 'name' and 'email'"
                )
            )
            continue

        try:
            recipient = RecipientIn.model_validate(item)
        except ValidationError as exc:
            results.append(
                RecipientResult(position, None, format_errors(exc), raw_name, raw_email)
            )
            continue

        key = recipient.email.lower()
        if key in first_seen:
            results.append(
                RecipientResult(
                    position,
                    None,
                    f"email: duplicate of recipient at position {first_seen[key]}",
                    raw_name,
                    raw_email,
                )
            )
            continue

        first_seen[key] = position
        results.append(RecipientResult(position, recipient, None, raw_name, raw_email))

    return results
