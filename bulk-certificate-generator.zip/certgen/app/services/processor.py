"""Background processing of a job: generate every pending certificate.

Design notes
------------
* One failure never aborts the job: each certificate is generated inside its own
  try/except and its outcome is committed immediately. That also makes progress
  visible to ``GET /jobs/{id}`` while the job is running.
* ``_claim_job`` is an atomic ``UPDATE ... WHERE status = 'queued'``; if two workers
  ever pick up the same job only one wins, so a job is never processed twice.
* Only ``pending`` rows are processed, so re-running a job (after a crash or a
  retry) resumes the remaining work instead of redoing finished certificates.
"""
from __future__ import annotations

import logging
from pathlib import Path

from sqlalchemy import select, update
from sqlalchemy.orm import Session, sessionmaker

from ..context import AppContext
from ..database import utcnow
from ..models import Certificate, CertificateStatus, FailureStage, Job, JobStatus
from .certificate import CertificateData
from .jobs import job_counts

logger = logging.getLogger(__name__)


def _claim_job(db: Session, job_id: str) -> bool:
    result = db.execute(
        update(Job)
        .where(Job.id == job_id, Job.status == JobStatus.QUEUED.value)
        .values(status=JobStatus.PROCESSING.value, started_at=utcnow(), finished_at=None)
    )
    db.commit()
    return result.rowcount == 1


def _generate_one(ctx: AppContext, job: Job, cert: Certificate) -> None:
    try:
        relative = Path(job.id) / f"{cert.certificate_number}.pdf"
        ctx.generator(
            CertificateData(
                name=cert.name,
                certificate_number=cert.certificate_number,
                event_name=job.event_name,
                issuer=job.issuer,
                issued_on=job.issued_on,
                achievement=cert.achievement,
            ),
            ctx.settings.storage_dir / relative,
        )
        cert.status = CertificateStatus.SUCCESS.value
        cert.file_path = relative.as_posix()
        cert.failure_stage = None
        cert.error = None
    except Exception as exc:  # noqa: BLE001 - isolate *any* per-certificate failure
        logger.exception("Certificate %s (job %s) failed", cert.id, job.id)
        cert.status = CertificateStatus.FAILED.value
        cert.failure_stage = FailureStage.GENERATION.value
        cert.file_path = None
        cert.error = f"{type(exc).__name__}: {exc}"[:500]
    finally:
        cert.completed_at = utcnow()


def _finalize(db: Session, job: Job) -> None:
    counts = job_counts(db, job.id)
    if counts.failed == 0:
        job.status = JobStatus.COMPLETED.value
    elif counts.succeeded == 0:
        job.status = JobStatus.FAILED.value
    else:
        job.status = JobStatus.COMPLETED_WITH_ERRORS.value
    job.finished_at = utcnow()
    db.commit()


def process_job(job_id: str, ctx: AppContext) -> None:
    """Entry point run in the background (FastAPI BackgroundTasks / startup recovery)."""
    with ctx.session_factory() as db:
        if not _claim_job(db, job_id):
            logger.info("Job %s not claimable (already running or finished); skipping", job_id)
            return

        job = db.get(Job, job_id)
        pending_ids = (
            db.execute(
                select(Certificate.id)
                .where(
                    Certificate.job_id == job_id,
                    Certificate.status == CertificateStatus.PENDING.value,
                )
                .order_by(Certificate.position)
            )
            .scalars()
            .all()
        )

        for cert_id in pending_ids:
            cert = db.get(Certificate, cert_id)
            _generate_one(ctx, job, cert)
            db.commit()  # one commit per certificate => live progress, no lost work

        _finalize(db, job)


def recover_incomplete_jobs(session_factory: sessionmaker[Session]) -> list[str]:
    """Re-queue jobs interrupted by a crash/restart and return the ids to resume.

    A job stuck in ``processing`` can only mean the process died mid-run
    (assumes a single app process; see README "Limitations").
    """
    with session_factory() as db:
        db.execute(
            update(Job)
            .where(Job.status == JobStatus.PROCESSING.value)
            .values(status=JobStatus.QUEUED.value)
        )
        db.commit()
        return list(
            db.execute(
                select(Job.id)
                .where(Job.status == JobStatus.QUEUED.value)
                .order_by(Job.created_at)
            ).scalars()
        )
