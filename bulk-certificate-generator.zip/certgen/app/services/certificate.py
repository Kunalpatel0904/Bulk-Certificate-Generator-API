"""The single predefined certificate template (landscape A4 PDF, ReportLab)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Callable

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import simpleSplit
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas

NAVY = HexColor("#1F2A44")
GOLD = HexColor("#B08D3C")
INK = HexColor("#2B2B2B")
MUTED = HexColor("#7A7A7A")
PAPER = HexColor("#FFFDF6")

PAGE_W, PAGE_H = landscape(A4)


@dataclass(frozen=True)
class CertificateData:
    name: str
    certificate_number: str
    event_name: str
    issuer: str
    issued_on: date
    achievement: str | None = None


#: A generator turns CertificateData into a PDF at ``output_path``. The processor
#: depends on this signature only, which keeps the renderer swappable (and lets
#: tests inject failures).
Generator = Callable[[CertificateData, Path], None]


def _fit_font_size(text: str, font: str, start: float, minimum: float, max_width: float) -> float:
    size = start
    while size > minimum and stringWidth(text, font, size) > max_width:
        size -= 1
    return size


def _draw(c: canvas.Canvas, d: CertificateData) -> None:
    cx = PAGE_W / 2

    # Background + double border
    c.setFillColor(PAPER)
    c.rect(0, 0, PAGE_W, PAGE_H, stroke=0, fill=1)
    c.setStrokeColor(NAVY)
    c.setLineWidth(4)
    c.rect(24, 24, PAGE_W - 48, PAGE_H - 48)
    c.setStrokeColor(GOLD)
    c.setLineWidth(1.5)
    c.rect(34, 34, PAGE_W - 68, PAGE_H - 68)

    # Heading
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 44)
    c.drawCentredString(cx, 478, "CERTIFICATE")
    c.setFillColor(GOLD)
    c.setFont("Helvetica", 15)
    c.drawCentredString(cx, 450, "O F   P A R T I C I P A T I O N")

    # Recipient (the name shrinks to fit rather than overflowing the border)
    c.setFillColor(INK)
    c.setFont("Times-Italic", 16)
    c.drawCentredString(cx, 398, "This certificate is proudly presented to")

    max_w = PAGE_W - 200
    size = _fit_font_size(d.name, "Times-BoldItalic", 42, 18, max_w)
    c.setFillColor(NAVY)
    c.setFont("Times-BoldItalic", size)
    c.drawCentredString(cx, 345, d.name)
    c.setStrokeColor(GOLD)
    c.setLineWidth(1)
    c.line(cx - 220, 332, cx + 220, 332)

    # Event
    c.setFillColor(INK)
    c.setFont("Times-Roman", 15)
    c.drawCentredString(cx, 300, "for successfully participating in")

    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 22)
    y = 268
    for line in simpleSplit(d.event_name, "Helvetica-Bold", 22, 620)[:3]:
        c.drawCentredString(cx, y, line)
        y -= 28

    if d.achievement:
        c.setFillColor(GOLD)
        c.setFont("Times-Italic", 16)
        c.drawCentredString(cx, y - 2, f"- {d.achievement} -")

    # Signature block
    c.setStrokeColor(INK)
    c.setLineWidth(0.8)
    for x in (190, PAGE_W - 190):
        c.line(x - 100, 112, x + 100, 112)
    c.setFillColor(INK)
    c.setFont("Helvetica", 12)
    c.drawCentredString(190, 118, f"{d.issued_on.day} {d.issued_on:%B %Y}")
    c.drawCentredString(PAGE_W - 190, 118, d.issuer)
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 9)
    c.drawCentredString(190, 98, "DATE OF ISSUE")
    c.drawCentredString(PAGE_W - 190, 98, "ISSUED BY")

    # Footer
    c.setFont("Helvetica", 9)
    c.drawCentredString(cx, 54, f"Certificate No. {d.certificate_number}")


def generate_certificate_pdf(data: CertificateData, output_path: Path) -> None:
    """Render ``data`` to ``output_path``.

    Written to a temp file and renamed so a crash never leaves a half-written PDF
    under the final name.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = output_path.with_name(output_path.name + ".tmp")
    try:
        c = canvas.Canvas(str(tmp_path), pagesize=landscape(A4))
        c.setTitle(f"Certificate - {data.name}")
        c.setAuthor(data.issuer)
        c.setSubject(data.event_name)
        _draw(c, data)
        c.showPage()
        c.save()
        os.replace(tmp_path, output_path)
    finally:
        tmp_path.unlink(missing_ok=True)
