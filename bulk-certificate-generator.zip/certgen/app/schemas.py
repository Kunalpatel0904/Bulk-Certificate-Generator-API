"""API request / response models."""
from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .models import CertificateStatus, FailureStage, JobStatus
from .services.validation import (
    MAX_EVENT_LEN,
    MAX_ISSUER_LEN,
    clean_text,
)

DEFAULT_ISSUER = "The Organizing Team"


class JobCreate(BaseModel):
    """Body of ``POST /api/v1/jobs``.

    ``recipients`` is intentionally loosely typed here: each item is validated
    one by one afterwards so a single bad row never rejects the entire request.
    """

    model_config = ConfigDict(
        str_strip_whitespace=True,
        json_schema_extra={
            "example": {
                "event_name": "Python Bootcamp 2026",
                "issuer": "Acme Academy",
                "issued_on": "2026-10-07",
                "recipients": [
                    {"name": "Asha Verma", "email": "asha@example.com"},
                    {
                        "name": "Rohan Mehta",
                        "email": "rohan@example.com",
                        "achievement": "Top Performer",
                    },
                ],
            }
        },
    )

    event_name: str
    issuer: str = DEFAULT_ISSUER
    issued_on: date | None = None
    recipients: list[Any] = Field(min_length=1)

    @field_validator("event_name")
    @classmethod
    def _event(cls, v: str) -> str:
        return clean_text(v, label="event_name", max_len=MAX_EVENT_LEN)

    @field_validator("issuer")
    @classmethod
    def _issuer(cls, v: str) -> str:
        return clean_text(v, label="issuer", max_len=MAX_ISSUER_LEN)


class JobCounts(BaseModel):
    total: int
    pending: int
    succeeded: int
    failed: int
    failed_validation: int
    failed_generation: int


class JobOut(BaseModel):
    job_id: str
    status: JobStatus
    event_name: str
    issuer: str
    issued_on: date
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None
    counts: JobCounts
    progress_percent: float
    links: dict[str, str]


class CertificateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    certificate_id: str
    position: int
    name: str | None
    email: str | None
    achievement: str | None
    status: CertificateStatus
    failure_stage: FailureStage | None
    error: str | None
    certificate_number: str | None
    completed_at: datetime | None
    download_url: str | None = None


class CertificateList(BaseModel):
    items: list[CertificateOut]
    total: int
    limit: int
    offset: int
