"""Runtime configuration, read from environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    #: SQLAlchemy URL. SQLite by default; any SQLAlchemy-supported RDBMS works
    #: (e.g. ``postgresql+psycopg://user:pass@host/db``).
    database_url: str = "sqlite:///./data/certgen.db"
    #: Directory where generated PDFs are written (one sub-directory per job).
    storage_dir: Path = Path("./data/certificates")
    #: Upper bound on recipients accepted in a single request.
    max_recipients_per_job: int = 1000

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            database_url=os.getenv("DATABASE_URL", cls.database_url),
            storage_dir=Path(os.getenv("STORAGE_DIR", str(cls.storage_dir))),
            max_recipients_per_job=int(
                os.getenv("MAX_RECIPIENTS_PER_JOB", cls.max_recipients_per_job)
            ),
        )
