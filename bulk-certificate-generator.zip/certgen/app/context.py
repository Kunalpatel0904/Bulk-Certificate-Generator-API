"""Shared application state, attached to ``app.state`` by the app factory."""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.orm import Session, sessionmaker

from .config import Settings
from .services.certificate import Generator


@dataclass(frozen=True)
class AppContext:
    settings: Settings
    session_factory: sessionmaker[Session]
    generator: Generator
