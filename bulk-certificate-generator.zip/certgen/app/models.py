"""Relational schema: one Job has many Certificate rows (one per recipient)."""
from __future__ import annotations

import enum
from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import Date, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from .database import Base, UTCDateTime, utcnow


class JobStatus(str, enum.Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"  # every recipient succeeded
    COMPLETED_WITH_ERRORS = "completed_with_errors"  # mix of success and failure
    FAILED = "failed"  # nothing succeeded


ACTIVE_JOB_STATUSES = (JobStatus.QUEUED.value, JobStatus.PROCESSING.value)
TERMINAL_JOB_STATUSES = (
    JobStatus.COMPLETED.value,
    JobStatus.COMPLETED_WITH_ERRORS.value,
    JobStatus.FAILED.value,
)


class CertificateStatus(str, enum.Enum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class FailureStage(str, enum.Enum):
    VALIDATION = "validation"  # bad input; retrying cannot help
    GENERATION = "generation"  # error while rendering; may be retried


def _uuid() -> str:
    return str(uuid4())


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    event_name: Mapped[str] = mapped_column(String(200))
    issuer: Mapped[str] = mapped_column(String(120))
    issued_on: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(32), index=True)
    total: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)


class Certificate(Base):
    __tablename__ = "certificates"
    __table_args__ = (
        UniqueConstraint("job_id", "position", name="uq_certificate_job_position"),
        Index("ix_certificates_job_status", "job_id", "status"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    job_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("jobs.id", ondelete="CASCADE"), index=True
    )
    #: 0-based position of the recipient in the submitted list, so a client can
    #: map every result back to the row it sent.
    position: Mapped[int] = mapped_column(Integer)
    name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    achievement: Mapped[str | None] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default=CertificateStatus.PENDING.value)
    failure_stage: Mapped[str | None] = mapped_column(String(16), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    #: Printed on the certificate. Only assigned to recipients that passed validation.
    certificate_number: Mapped[str | None] = mapped_column(String(40), nullable=True)
    #: Path relative to STORAGE_DIR, so the storage directory can be relocated.
    file_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
