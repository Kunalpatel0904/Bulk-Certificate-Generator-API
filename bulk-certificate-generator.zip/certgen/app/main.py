"""FastAPI application factory.

Run with:  uvicorn app.main:create_app --factory
"""
from __future__ import annotations

import logging
import threading
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy.orm import sessionmaker

from .config import Settings
from .context import AppContext
from .database import Base, make_engine
from .routers.jobs import router as jobs_router
from .services.certificate import Generator, generate_certificate_pdf
from .services.processor import process_job, recover_incomplete_jobs

logger = logging.getLogger(__name__)


def create_app(settings: Settings | None = None, generator: Generator | None = None) -> FastAPI:
    """Build the app. ``settings`` and ``generator`` are injectable for tests."""
    settings = settings or Settings.from_env()
    settings.storage_dir.mkdir(parents=True, exist_ok=True)

    engine = make_engine(settings.database_url)
    Base.metadata.create_all(engine)  # simple bootstrap; use Alembic for real migrations
    ctx = AppContext(
        settings=settings,
        session_factory=sessionmaker(engine, expire_on_commit=False),
        generator=generator or generate_certificate_pdf,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Resume anything a previous crash/restart left unfinished.
        job_ids = recover_incomplete_jobs(ctx.session_factory)
        if job_ids:
            logger.info("Resuming %d interrupted job(s)", len(job_ids))

            def _resume() -> None:
                for job_id in job_ids:
                    process_job(job_id, ctx)

            threading.Thread(target=_resume, name="job-recovery", daemon=True).start()
        yield
        engine.dispose()

    app = FastAPI(
        title="Bulk Certificate Generator",
        version="1.0.0",
        description="Submit a list of recipients, get certificates generated in the background.",
        lifespan=lifespan,
    )
    app.state.ctx = ctx
    app.include_router(jobs_router, prefix="/api/v1")

    @app.get("/health", tags=["meta"])
    def health() -> dict[str, str]:
        return {"status": "ok"}

    return app
