"""HTTP API: create jobs, track progress, retrieve certificates."""
from __future__ import annotations

import logging
import re
import tempfile
import zipfile
from datetime import timezone
from typing import Iterator

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from ..context import AppContext
from ..database import utcnow
from ..models import (
    TERMINAL_JOB_STATUSES,
    Certificate,
    CertificateStatus,
    FailureStage,
    Job,
    JobStatus,
)
from ..schemas import CertificateList, CertificateOut, JobCreate, JobOut
from ..services.jobs import API_PREFIX, build_job_out
from ..services.processor import process_job
from ..services.validation import validate_recipients

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/jobs", tags=["jobs"])


# --------------------------------------------------------------------------- deps
def get_ctx(request: Request) -> AppContext:
    return request.app.state.ctx


def get_db(ctx: AppContext = Depends(get_ctx)) -> Iterator[Session]:
    with ctx.session_factory() as db:
        yield db


def _get_job_or_404(db: Session, job_id: str) -> Job:
    job = db.get(Job, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


def _get_certificate_or_404(db: Session, job_id: str, certificate_id: str) -> Certificate:
    cert = db.get(Certificate, certificate_id)
    if cert is None or cert.job_id != job_id:
        raise HTTPException(status_code=404, detail="Certificate not found")
    return cert


def _cert_out(cert: Certificate) -> CertificateOut:
    out = CertificateOut(
        certificate_id=cert.id,
        position=cert.position,
        name=cert.name,
        email=cert.email,
        achievement=cert.achievement,
        status=cert.status,
        failure_stage=cert.failure_stage,
        error=cert.error,
        certificate_number=cert.certificate_number,
        completed_at=cert.completed_at,
    )
    if cert.status == CertificateStatus.SUCCESS.value:
        out.download_url = f"{API_PREFIX}/jobs/{cert.job_id}/certificates/{cert.id}/file"
    return out


# ----------------------------------------------------------------------- endpoints
@router.post(
    "",
    response_model=JobOut,
    status_code=202,
    summary="Submit a bulk certificate generation job",
)
def create_job(
    payload: JobCreate,
    background_tasks: BackgroundTasks,
    response: Response,
    ctx: AppContext = Depends(get_ctx),
    db: Session = Depends(get_db),
) -> JobOut:
    """Validate the recipients, persist the job and generate certificates in the background.

    Returns ``202 Accepted`` immediately with the job id; poll ``GET /jobs/{id}``.
    Invalid recipients do not reject the request: they are recorded as failed
    certificates (stage ``validation``) with the reason, and valid ones proceed.
    """
    limit = ctx.settings.max_recipients_per_job
    if len(payload.recipients) > limit:
        raise HTTPException(
            status_code=413,
            detail=f"Too many recipients: {len(payload.recipients)} (maximum {limit} per job)",
        )

    results = validate_recipients(payload.recipients)
    has_valid = any(r.error is None for r in results)
    now = utcnow()

    job = Job(
        event_name=payload.event_name,
        issuer=payload.issuer,
        issued_on=payload.issued_on or now.astimezone(timezone.utc).date(),
        status=JobStatus.QUEUED.value if has_valid else JobStatus.FAILED.value,
        total=len(results),
    )
    if not has_valid:  # nothing to generate; the job is already finished
        job.started_at = job.finished_at = now
    db.add(job)
    db.flush()  # assigns job.id

    certs = []
    for r in results:
        if r.error is None:
            certs.append(
                Certificate(
                    job_id=job.id,
                    position=r.position,
                    name=r.recipient.name,
                    email=r.recipient.email,
                    achievement=r.recipient.achievement,
                    certificate_number=f"CERT-{job.id[:8].upper()}-{r.position + 1:05d}",
                    status=CertificateStatus.PENDING.value,
                )
            )
        else:
            certs.append(
                Certificate(
                    job_id=job.id,
                    position=r.position,
                    name=r.raw_name,
                    email=r.raw_email,
                    status=CertificateStatus.FAILED.value,
                    failure_stage=FailureStage.VALIDATION.value,
                    error=r.error,
                    completed_at=now,
                )
            )
    db.add_all(certs)
    db.commit()  # committed *before* the background task starts

    if has_valid:
        background_tasks.add_task(process_job, job.id, ctx)

    response.headers["Location"] = f"{API_PREFIX}/jobs/{job.id}"
    return build_job_out(db, job)


@router.get("/{job_id}", response_model=JobOut, summary="Job status and progress")
def get_job(job_id: str, db: Session = Depends(get_db)) -> JobOut:
    return build_job_out(db, _get_job_or_404(db, job_id))


@router.get(
    "/{job_id}/certificates",
    response_model=CertificateList,
    summary="List per-recipient results (paginated)",
)
def list_certificates(
    job_id: str,
    status: CertificateStatus | None = Query(None, description="Filter by status"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
) -> CertificateList:
    _get_job_or_404(db, job_id)
    query = select(Certificate).where(Certificate.job_id == job_id)
    if status is not None:
        query = query.where(Certificate.status == status.value)

    total = db.execute(select(func.count()).select_from(query.subquery())).scalar_one()
    rows = db.execute(query.order_by(Certificate.position).limit(limit).offset(offset)).scalars()
    return CertificateList(
        items=[_cert_out(c) for c in rows], total=total, limit=limit, offset=offset
    )


@router.post(
    "/{job_id}/retry",
    response_model=JobOut,
    status_code=202,
    summary="Re-run certificates that failed during generation",
)
def retry_job(
    job_id: str,
    background_tasks: BackgroundTasks,
    ctx: AppContext = Depends(get_ctx),
    db: Session = Depends(get_db),
) -> JobOut:
    """Retries *generation* failures only; validation failures need corrected input
    and therefore a new job."""
    _get_job_or_404(db, job_id)

    # Atomically move the job back to 'queued' so concurrent retries can't both win.
    claimed = db.execute(
        update(Job)
        .where(Job.id == job_id, Job.status.in_(TERMINAL_JOB_STATUSES))
        .values(status=JobStatus.QUEUED.value, finished_at=None)
    )
    if claimed.rowcount != 1:
        db.rollback()
        raise HTTPException(status_code=409, detail="Job is still queued or processing")

    reset = db.execute(
        update(Certificate)
        .where(
            Certificate.job_id == job_id,
            Certificate.status == CertificateStatus.FAILED.value,
            Certificate.failure_stage == FailureStage.GENERATION.value,
        )
        .values(
            status=CertificateStatus.PENDING.value,
            failure_stage=None,
            error=None,
            completed_at=None,
        )
    )
    if reset.rowcount == 0:
        db.rollback()
        raise HTTPException(status_code=409, detail="No generation failures to retry")

    db.commit()
    background_tasks.add_task(process_job, job_id, ctx)
    db.expire_all()
    return build_job_out(db, db.get(Job, job_id))


@router.get(
    "/{job_id}/certificates/{certificate_id}",
    response_model=CertificateOut,
    summary="Single certificate record",
)
def get_certificate(job_id: str, certificate_id: str, db: Session = Depends(get_db)) -> CertificateOut:
    _get_job_or_404(db, job_id)
    return _cert_out(_get_certificate_or_404(db, job_id, certificate_id))


@router.get(
    "/{job_id}/certificates/{certificate_id}/file",
    summary="Download one generated certificate (PDF)",
    response_class=FileResponse,
)
def download_certificate(
    job_id: str,
    certificate_id: str,
    ctx: AppContext = Depends(get_ctx),
    db: Session = Depends(get_db),
):
    _get_job_or_404(db, job_id)
    cert = _get_certificate_or_404(db, job_id, certificate_id)
    if cert.status != CertificateStatus.SUCCESS.value or not cert.file_path:
        raise HTTPException(
            status_code=409, detail=f"Certificate is not available (status: {cert.status})"
        )
    path = ctx.settings.storage_dir / cert.file_path
    if not path.is_file():
        raise HTTPException(status_code=410, detail="Certificate file is no longer available")
    return FileResponse(path, media_type="application/pdf", filename=f"{cert.certificate_number}.pdf")


def _safe_filename(position: int, name: str | None) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "_", name or "").strip("_")[:40] or "certificate"
    return f"{position + 1:05d}_{slug}.pdf"


@router.get(
    "/{job_id}/download",
    summary="Download all successfully generated certificates as a ZIP",
    response_class=StreamingResponse,
)
def download_all(
    job_id: str,
    ctx: AppContext = Depends(get_ctx),
    db: Session = Depends(get_db),
):
    job = _get_job_or_404(db, job_id)
    if job.status not in TERMINAL_JOB_STATUSES:
        raise HTTPException(status_code=409, detail=f"Job is still {job.status}")

    certs = db.execute(
        select(Certificate)
        .where(Certificate.job_id == job_id, Certificate.status == CertificateStatus.SUCCESS.value)
        .order_by(Certificate.position)
    ).scalars()

    # Spill to disk past 32 MB so a big job doesn't sit in memory.
    buffer = tempfile.SpooledTemporaryFile(max_size=32 * 1024 * 1024)
    added = 0
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for cert in certs:
            path = ctx.settings.storage_dir / (cert.file_path or "")
            if not cert.file_path or not path.is_file():
                logger.warning("Certificate file missing for %s; skipped in ZIP", cert.id)
                continue
            zf.write(path, arcname=_safe_filename(cert.position, cert.name))
            added += 1

    if added == 0:
        buffer.close()
        raise HTTPException(status_code=409, detail="No generated certificates available")

    size = buffer.seek(0, 2)
    buffer.seek(0)

    def stream() -> Iterator[bytes]:
        try:
            while chunk := buffer.read(64 * 1024):
                yield chunk
        finally:
            buffer.close()

    return StreamingResponse(
        stream(),
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="certificates-{job_id}.zip"',
            "Content-Length": str(size),
        },
    )
